import hashlib,json,threading,zipfile
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from playwright.sync_api import sync_playwright
archive=Path('/workspace/artifacts/bubu-v2-remaining-20261024/bubu-v2-interactive.zip')
output=archive.parent/'offline-package.json';root=Path('/tmp/bubu-v2-offline-remaining-20261024');root.mkdir(exist_ok=False)
report={'status':'running','packageSHA256':hashlib.sha256(archive.read_bytes()).hexdigest(),'productionAccepted':False,'errors':[],'scenes':[],'externalRequests':[]}
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=None
try:
 with zipfile.ZipFile(archive) as z:
  for name in z.namelist():assert root.resolve() in (root/name).resolve().parents,name
  z.extractall(root)
 manifest=json.loads((root/'SHA256SUMS.json').read_text())
 for name,sha in manifest.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
 report['hashVerifiedFiles']=len(manifest)
 server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(root/'site')));threading.Thread(target=server.serve_forever,daemon=True).start()
 origin=f'http://127.0.0.1:{server.server_port}'
 with sync_playwright() as pw:
  b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']);p=b.new_page(viewport={'width':1100,'height':900})
  p.on('pageerror',lambda e:report['errors'].append(str(e)))
  p.on('response',lambda r:report['errors'].append(f'{r.status}: {r.url}') if r.status>=400 else None)
  p.on('request',lambda r:report['externalRequests'].append(r.url) if not r.url.startswith((origin+'/', 'data:', 'blob:')) else None)
  p.goto(origin+'/animation-foundation-v1/demo/?capture',wait_until='networkidle',timeout=120000);p.wait_for_function("document.documentElement.dataset.ready==='true'",timeout=120000)
  for name in ['bare','ear','satchel','cape','book','halo','wardrobe','tea']:
   state=p.evaluate('''async(name)=>{const a=await import('./app.mjs');await a.select(name);for(let i=0;i<12;i++)a.advance(1/24);return a.snapshot();}''',name)
   assert not state['errors'],state;report['scenes'].append({'name':name,'mounts':state['mounts'],'resources':state['resources']})
  assert not report['errors'] and not report['externalRequests'],report
  p.evaluate("async()=>{(await import('./app.mjs')).dispose()}");b.close()
 report['status']='passed'
except Exception as e:
 report['status']='failed';report['failure']=str(e);raise
finally:
 if server:server.shutdown();server.server_close()
 output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'files':report.get('hashVerifiedFiles'),'scenes':len(report['scenes'])}))
