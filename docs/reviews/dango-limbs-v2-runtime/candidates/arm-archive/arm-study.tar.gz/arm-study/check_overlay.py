#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
import argparse,json,hashlib
H=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--canonical-package',type=Path,required=True);p.add_argument('--overlay',type=Path,required=True);p.add_argument('--verify',action='store_true');a=p.parse_args();B=a.canonical_package.resolve();O=a.overlay.resolve();E=H/'expected-overlay'
def sha(q):return hashlib.sha256(q.read_bytes()).hexdigest()
def path(s):return O/s if (O/s).exists()else B/s
frames=json.load(open(O/'fore-frames.json'))+json.load(open(O/'level-support-frames.json'));palette={(248,104,120),(248,128,128),(240,80,104),(26,27,38)}
for f in frames:
 im=Image.open(O/f['src']).convert('RGBA');assert set(im.getchannel('A').getdata())<={0,255};assert {x[:3]for x in im.getdata()if x[3]}<=palette;assert Image.open(O/f['productionSrc']).convert('RGBA').tobytes()==im.resize((im.width*8,im.height*8),Image.Resampling.NEAREST).tobytes();assert sha(O/f['src'])==f['sha256'];assert path(f['source']).is_file()
rows=json.load(open(O/'joints/elbow.json'))['frames'];m=json.load(open(O/'limbs.json'));mf={x['src']:x for kind in m['segments'].values()for x in kind.get('frames',[])}
for j in rows:
 assert j['alphaUnchanged'];u=mf[j['sourceUpper']];f=mf[j['sourceFore']];assert sha(path(u['src']))==j['sourceUpperSha256'];assert sha(path(f['src']))==j['sourceForeSha256'];union=Image.new('RGBA',j['size'])
 for rec,root in [(u,j['upperRoot']),(f,j['root'])]:union.alpha_composite(Image.open(path(rec['src'])),tuple(int(root[k]-rec['root'][k])for k in [0,1]))
 alpha=union.getchannel('A').tobytes()
 for edit in j['changedPixels']:
  xy=tuple(edit['xy']);assert list(union.getpixel(xy))==edit['before'];union.putpixel(xy,tuple(edit['after']))
 assert union.getchannel('A').tobytes()==alpha
verified=[]
if a.verify:
 for expected in E.rglob('*'):
  if expected.is_file():
   rel=expected.relative_to(E);assert (O/rel).exists(),str(rel);assert sha(expected)==sha(O/rel),str(rel);verified.append(str(rel))
report={'newBaseFrames':len(frames),'distinctForeFrames':16,'newLevelSupportFrames':2,'jointPairs':len(rows),'allowedPairs':sum(x['allowedByBendLimit']for x in rows),'allJointAlphaUnchanged':True,'expectedOverlayFilesByteMatched':len(verified),'canonicalAssetsCopied':False,'wholeBodyReplacements':False,'runtimeAccepted':False,'sourceStatus':'fore static source/assembly passed; runtime wrist seams not accepted; level support strict pass 64/516'}
(O/'overlay-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
