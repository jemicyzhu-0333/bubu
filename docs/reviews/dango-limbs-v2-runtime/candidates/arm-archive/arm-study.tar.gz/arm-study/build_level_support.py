from pathlib import Path
from PIL import Image,ImageDraw
import json,math,hashlib,copy
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--canonical-package',required=True,type=Path);parser.add_argument('--output',required=True,type=Path);args=parser.parse_args();BASE=args.canonical_package.resolve();ROOT=args.output.resolve();assert ROOT!=BASE and BASE not in ROOT.parents
(ROOT/'paw').mkdir(parents=True,exist_ok=True)
m=json.load(open(ROOT/'limbs.json'));recipe=json.load(open(ROOT/'sources/rebuild-recipe.json'));palette=recipe['palette'];new=[];sheet=Image.new('RGB',(600,260),'#f1f3ee');d=ImageDraw.Draw(sheet)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for ci,view in enumerate(['front','three-quarter-left']):
 base=m['paws']['support']['views'][view][0];f=copy.deepcopy(base);n=base['contactResolution']['projectedNormal'];angle=(90-math.degrees(math.atan2(n[1],n[0])))%360;r=math.radians(angle);c,s=math.cos(r),math.sin(r);A=base['inverseSamplingMatrix'];inv=[[A[0][0]*c-A[0][1]*s,A[0][0]*s+A[0][1]*c],[A[1][0]*c-A[1][1]*s,A[1][0]*s+A[1][1]*c]];root=[18.5,18.5];sr=base['sourceRootCenter'];mat=[[inv[j][0],inv[j][1],sr[j]-inv[j][0]*root[0]-inv[j][1]*root[1]]for j in range(2)];src=Image.open((ROOT/base['source']) if (ROOT/base['source']).exists() else (BASE/base['source'])).convert('RGBA');im=Image.new('RGBA',(37,37))
 for y in range(37):
  for x in range(37):
   u=math.floor(mat[0][0]*(x+.5)+mat[0][1]*(y+.5)+mat[0][2]);v=math.floor(mat[1][0]*(x+.5)+mat[1][1]*(y+.5)+mat[1][2]);
   if 0<=u<src.width and 0<=v<src.height:
    p=src.getpixel((u,v))
    if p[3]:im.putpixel((x,y),(*min(palette,key=lambda q:sum((p[k]-q[k])**2 for k in range(3))),255))
 # Quantize actual observed source contact to an opaque maximal downward boundary.
 contact=base['contactResolution']['sourceContactPointCropCenter'];v=[contact[j]-sr[j]for j in range(2)];det=inv[0][0]*inv[1][1]-inv[0][1]*inv[1][0];ideal=[root[0]+(inv[1][1]*v[0]-inv[0][1]*v[1])/det,root[1]+(-inv[1][0]*v[0]+inv[0][0]*v[1])/det];ys=[y for y in range(37)for x in range(37)if im.getpixel((x,y))[3]];bottom=max(ys);xs=[x for x in range(37)if im.getpixel((x,bottom))[3]];gx=min(xs,key=lambda x:abs(x+.5-ideal[0]));grip=[gx+.5,bottom+.5]
 path=f'paw/paw-support-l-{view}-level.png';im.save(ROOT/path);im.resize((296,296),Image.Resampling.NEAREST).save(ROOT/path.replace('.png','@8x.png'));pv=Image.new('RGBA',im.size);pv.putpixel(tuple(map(int,root)),(255,0,0,255));pv.putpixel(tuple(map(int,grip)),(0,0,255,255));pv.save(ROOT/path.replace('.png','.pivot.png'))
 f.update(src=path,productionSrc=path.replace('.png','@8x.png'),pivot=path.replace('.png','.pivot.png'),size=[37,37],root=root,grip=grip,bounds=list(im.getbbox()),inverseSamplingMatrix=mat,offlineRotationDegrees=base['offlineRotationDegrees']+angle,gripIdeal=ideal,gripSnapError=[grip[j]-ideal[j]for j in range(2)],pixelEdits=[],sha256=sha(ROOT/path));f.pop('beforeRepairSha256',None);f['semantic'].update(nominalAngle=angle,sourceFrame=base['semantic']['sourceFrame']+'-level',status='Candidate exact normal-aligned source reprojection; needs planted surface/runtime review');f['contactResolution'].update(projectedNormal=[0,1],maximumProjection=grip[1],policy='Preserved source surface rotated offline to exactly downward; grip is an opaque bottom-row pixel nearest transformed source contact.');m['paws']['support']['views'][view].append(f);recipe['frames'].append(f);new.append(f)
 d.text((ci*300+5,5),view+f' axis {angle:.1f} / normal down',fill='black');big=im.resize((148,148),Image.Resampling.NEAREST);sheet.paste(big,(ci*300+15,35),big);d.line([(ci*300,35+int(grip[1]*4)),(ci*300+190,35+int(grip[1]*4))],fill='#7d8883');d.text((ci*300+5,220),f'grip {grip}, source-only pixels',fill='black')
m['extensions']['baseFrameCount']=len(recipe['frames']);(ROOT/'limbs.json').write_text(json.dumps(m,indent=2)+'\n');(ROOT/'sources/rebuild-recipe.json').write_text(json.dumps(recipe,indent=2)+'\n');(ROOT/'level-support-frames.json').write_text(json.dumps(new,indent=2)+'\n');sheet.save(ROOT/'level-support-review.png');print([(f['src'],f['semantic']['nominalAngle'],f['grip'],f['bounds'])for f in new])
