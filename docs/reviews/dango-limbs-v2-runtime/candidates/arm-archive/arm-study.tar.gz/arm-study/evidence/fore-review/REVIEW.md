# Independent distinct forearm review

Verdict: source-distinct forearm passes extraction/provenance checks and preserves approved upper/body files. Do not promote the three reviewed runtime actions. Their forced one-frame composites retain contact and root defects. Static cup/wave remain useful asset-only evidence.

## Verified source and assembly facts

- Inspected approved full-character-v2 and short-arm-study-v2. The new forearm uses a visibly tapered observed forearm strip rather than another copy of the upper arm. The full generated study is reference only, not a replacement body.
- All 16 upper-arm PNGs are byte-identical to baseline. All 16 forearm PNGs differ from baseline fore and corresponding upper.
- Independently recomputed each of the 16 inverse-sampling outputs from its saved crop and declared matrix: exact RGBA match. Uniform source scale is 69.415385 / 458 = 0.15156197598253277 art units/source pixel. No post-extraction nonuniform scale is present.
- Independently reconstructed the source alpha union and applied declared edits for all 256 elbow pairs: alpha preserved exactly. This proves no additional silhouette alpha is invented by repairs; it does not prove every joint contour looks natural.
- Source pack body PNGs equal current production canonical front, three-quarter-left and back body PNGs byte for byte; upper source, face and body were not substituted in diagnostic artist.
- Read-only packaged checker passes 240 base layers, 256 pairs, 208 legal pairs.
- Independent five-pose static rebuild matches supplied previews pixel for pixel, including cup and wave. At native/2× the short-limb proportions are retained. The registered static cup uses contact pixels reported in registration.json, with both wrist-lattice targets exact; this is separate from runtime cup trajectories.

## Forced actual artist diagnostic

`forced-action-native-3x.png` renders current artist at progress .5 for sip-tea, hiccup and type-keyboard with candidate pack loaded. Review-local artist and composer copies bypass the action-wide gate AND per-frame maximum-error rejection solely to show every candidate limb. All imports otherwise point at current production modules. Production files were never edited. Image is not evidence that normal runtime enabled these limbs.

Actual grip/target versus selected contact, art units:

- sip-tea left target (25.296795,46.403846), selected contact (25.5,47.5): error 1.114830. Right target (44.921795,46.403846), selected contact (44.5,49.5): error 3.124753.
- hiccup left true grip (22.875,48.375), selected contact (23.5,49.5): error 1.286954. Right true grip (42.5,48.375), selected contact (42.5,49.5): error 1.125000.
- type-keyboard left surface target (23,57.125), selected contact (18.5,56.5): error 4.543195. Right surface target (44.875,57.125), selected contact (47.5,56.5): error 2.698379.

sip-tea provides endpoint targets rather than separate gripPoint fields; hiccup explicitly provides gripPoint. Keyboard uses downward surface normal. These are marker errors against the current action contract, not a claim that visual surface collision has been solved.

Visible remaining problems:

1. sip-tea and hiccup have an exposed pink/ink arm fragment at the lower screen-right body edge, associated with fixed right shoulder (61.5,45.5). A tapered forearm does not by itself remove this.
2. Front hold paw proximal cuts remain visible as open pink joins on the belly; the selective wave interface is not a general hold-root repair.
3. Keyboard paws do not land at authored surface targets; visually plausible overlap is insufficient when lateral errors exceed 2.6/4.5 units.
4. Forced static frames are not action-wide animation, transition, outfit, loop, cache, native Electron or full source acceptance.

Keep normal conservative fallback. Next repair should target fixed-shoulder action registration/contact trajectories and pose-specific root/exterior coverage, without moving canonical body or pretending alpha connectivity resolves the contour.

## Artifacts

- independent-checks.json and check_independent.py
- current-body-equality.json
- pack-check.log
- static-rebuild/ and static-rebuild.log
- forced-action-native-3x.png and forced-records.json
- audit.mjs, forced-artist.mjs, forced-compose.mjs (diagnostic only)
