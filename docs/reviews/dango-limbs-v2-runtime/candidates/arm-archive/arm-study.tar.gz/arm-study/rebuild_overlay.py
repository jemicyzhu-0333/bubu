#!/usr/bin/env python3
"""Build only the arm-study overlay, requiring an external canonical package."""
from pathlib import Path
import argparse,json,hashlib,shutil,subprocess,sys
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--canonical-package',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--verify',action='store_true');a=p.parse_args();base=a.canonical_package.resolve();out=a.output.resolve()
if out==base or base in out.parents or out==HERE or HERE in out.parents:raise SystemExit('Use a fresh output outside canonical package and staging bundle.')
if out.exists() and any(out.iterdir()):raise SystemExit('Output must be new or empty; refusing overwrite.')
def sha(q):return hashlib.sha256(q.read_bytes()).hexdigest()
for name,expected in json.load(open(HERE/'canonical-dependency.json'))['requiredFiles'].items():
 if not (base/name).is_file()or sha(base/name)!=expected:raise SystemExit('Canonical dependency mismatch: '+name)
out.mkdir(parents=True,exist_ok=True);(out/'sources/masters').mkdir(parents=True,exist_ok=True)
for q in (HERE/'masters').iterdir():shutil.copy2(q,out/'sources/masters'/q.name)
def run(name):subprocess.run([sys.executable,str(HERE/name),'--canonical-package',str(base),'--output',str(out)],check=True)
run('build_forearm.py');m=json.load(open(base/'limbs.json'));r=json.load(open(base/'sources/rebuild-recipe.json'));fore=json.load(open(out/'fore-frames.json'));m['segments']['arm-fore-l']['frames']=fore;replace={f['src']:f for f in fore};r['frames']=[replace.get(f['src'],f)for f in r['frames']];m.setdefault('extensions',{})['runtimeReady']=False
(out/'limbs.json').write_text(json.dumps(m,indent=2)+'\n');(out/'sources/rebuild-recipe.json').write_text(json.dumps(r,indent=2)+'\n')
run('build_level_support.py');run('build_joint_pairs.py')
subprocess.run([sys.executable,str(HERE/'check_overlay.py'),'--canonical-package',str(base),'--overlay',str(out),*(['--verify']if a.verify else[])],check=True)
